<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=to_do',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
